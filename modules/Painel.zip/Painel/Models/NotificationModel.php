<?php
namespace Modules\Painel\Models;

use Nopadi\MVC\Model;

class NotificationModel extends Model
    {
	  /*Prover o acesso estático ao modelo*/
	  public static function model()
	  {
		return new NotificationModel();
	  } 	
    }

